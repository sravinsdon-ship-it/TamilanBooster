package com.tamilan.booster

import android.app.*
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.*
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private var view: TextView? = null
    private lateinit var wm: WindowManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("boost", "Booster", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "boost").setContentTitle("Tamilan Booster active")
            .setSmallIcon(android.R.drawable.ic_menu_manage).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val p = WindowManager.LayoutParams(150, 150, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START; p.x = 0; p.y = 300
        val v = TextView(this).apply {
            text = "🚀"; textSize = 26f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(200, 255, 87, 34)) }
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - sx) > 10 || Math.abs(e.rawY - sy) > 10) moved = true
                    p.x = ox + (e.rawX - sx).toInt(); p.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(v, p)
                }
                MotionEvent.ACTION_UP -> if (!moved) Thread {
                    val mb = Boost.clean(this)
                    v.post { Toast.makeText(this, "Freed ~$mb MB • ${Boost.availMb(this)} MB free", Toast.LENGTH_SHORT).show() }
                }.start()
            }
            true
        }
        view = v; wm.addView(v, p)
    }

    override fun onDestroy() { view?.let { wm.removeView(it) }; super.onDestroy() }
}
