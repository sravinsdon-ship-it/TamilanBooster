package com.tamilan.booster

import android.app.*
import android.content.*
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var stats: TextView
    private lateinit var gameList: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("games", MODE_PRIVATE) }
    private val ORANGE = Color.rgb(255, 87, 34)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.rgb(18, 18, 24)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40); setBackgroundColor(Color.rgb(18, 18, 24)) }
        root.addView(tv("TAMILAN BOOSTER", 26f, ORANGE, true))
        root.addView(tv("Ultimate Game Space", 13f, Color.GRAY, false))
        stats = tv("", 15f, Color.WHITE, false).apply { setPadding(30, 30, 30, 30); background = card() }
        root.addView(stats, lp(24))
        root.addView(btn("⚡ ONE-TAP BOOST") { boostNow() }, lp(20))
        root.addView(row(btn("🔕 Game DND") { toggleDnd() }, btn("☀ Max Brightness") { toggleBrightness() }))
        root.addView(row(btn("🎈 Floating Boost") { toggleOverlay() }, btn("🔋 Battery Saver") { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }))
        root.addView(row(btn("📶 Network") { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }, btn("🧹 Storage") { startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }))
        root.addView(tv("MY GAMES", 14f, ORANGE, true), lp(28))
        gameList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(gameList)
        root.addView(btn("＋ Add Games") { pickGames() }, lp(12))
        setContentView(ScrollView(this).apply { addView(root) })
        renderGames()
    }

    override fun onResume() { super.onResume(); tick.run() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private val tick = object : Runnable {
        override fun run() {
            val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
            val lvl = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            val freeGb = StatFs(Environment.getDataDirectory().path).availableBytes / 1073741824.0
            stats.text = "RAM  ${Boost.availMb(this@MainActivity)} / ${Boost.totalMb(this@MainActivity)} MB free\n" +
                "Battery  $lvl%   •   Temp  $temp°C\nStorage  ${"%.1f".format(freeGb)} GB free\n" +
                "DND  ${if (dndOn()) "ON" else "OFF"}"
            h.postDelayed(this, 2000)
        }
    }

    private fun boostNow() {
        toast("Boosting…")
        Thread { val mb = Boost.clean(this); runOnUiThread { toast("Freed ~$mb MB") } }.start()
    }

    private fun nm() = getSystemService(NotificationManager::class.java)
    private fun dndOn() = nm().currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_NONE

    private fun toggleDnd() {
        if (!nm().isNotificationPolicyAccessGranted) {
            toast("Allow Tamilan Booster, then come back")
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)); return
        }
        nm().setInterruptionFilter(if (dndOn()) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_NONE)
    }

    private var oldBright = -1
    private fun toggleBrightness() {
        if (!Settings.System.canWrite(this)) {
            toast("Allow modify settings, then come back")
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))); return
        }
        val cr = contentResolver
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        if (oldBright < 0) {
            oldBright = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, 255); toast("Brightness max")
        } else {
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, oldBright); oldBright = -1; toast("Brightness restored")
        }
    }

    private var overlayOn = false
    private fun toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow display over other apps")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val i = Intent(this, OverlayService::class.java)
        overlayOn = !overlayOn
        if (overlayOn) startForegroundService(i) else stopService(i)
        toast(if (overlayOn) "Floating button on" else "Floating button off")
    }

    private fun launchables(): List<ResolveInfo> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }

    private fun pickGames() {
        val apps = launchables()
        val names = apps.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        val saved = prefs.getStringSet("g", emptySet())!!
        val checked = BooleanArray(apps.size) { apps[it].activityInfo.packageName in saved }
        AlertDialog.Builder(this).setTitle("Select games")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putStringSet("g", apps.indices.filter { checked[it] }.map { apps[it].activityInfo.packageName }.toSet()).apply()
                renderGames()
            }.show()
    }

    private fun renderGames() {
        gameList.removeAllViews()
        val saved = prefs.getStringSet("g", emptySet())!!
        if (saved.isEmpty()) gameList.addView(tv("No games yet. Tap Add Games.", 13f, Color.GRAY, false))
        saved.forEach { pkg ->
            val info = try { packageManager.getApplicationInfo(pkg, 0) } catch (e: Exception) { return@forEach }
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(24, 20, 24, 20); background = card() }
            r.addView(ImageView(this).apply { setImageDrawable(packageManager.getApplicationIcon(info)) }, LinearLayout.LayoutParams(110, 110))
            r.addView(tv(packageManager.getApplicationLabel(info).toString(), 16f, Color.WHITE, false).apply { setPadding(24, 0, 0, 0) },
                LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(btn("PLAY") { playGame(pkg) })
            gameList.addView(r, lp(10))
        }
    }

    private fun playGame(pkg: String) {
        toast("Boosting & launching…")
        Thread {
            Boost.clean(this)
            runOnUiThread {
                if (nm().isNotificationPolicyAccessGranted) nm().setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
                packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
            }
        }.start()
    }

    private fun card() = GradientDrawable().apply { cornerRadius = 28f; setColor(Color.rgb(32, 33, 44)) }
    private fun tv(t: String, s: Float, c: Int, bold: Boolean) = TextView(this).apply { text = t; textSize = s; setTextColor(c); if (bold) setTypeface(typeface, Typeface.BOLD) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); isAllCaps = false
        background = GradientDrawable().apply { cornerRadius = 28f; setColor(ORANGE) }
        setOnClickListener { f() }
    }
    private fun row(a: View, b: View) = LinearLayout(this).apply {
        addView(a, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 8 })
        addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 8 })
    }
    private fun lp(top: Int) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = top }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
