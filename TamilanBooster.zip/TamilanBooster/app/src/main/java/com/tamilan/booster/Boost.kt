package com.tamilan.booster

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo

object Boost {
    private fun info(c: Context): ActivityManager.MemoryInfo {
        val i = ActivityManager.MemoryInfo()
        (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(i)
        return i
    }
    fun availMb(c: Context) = info(c).availMem / 1048576
    fun totalMb(c: Context) = info(c).totalMem / 1048576
    fun clean(c: Context): Long {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = availMb(c)
        c.packageManager.getInstalledApplications(0)
            .filter { it.packageName != c.packageName && (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .forEach { am.killBackgroundProcesses(it.packageName) }
        Thread.sleep(400)
        return (availMb(c) - before).coerceAtLeast(0)
    }
}
